import Header from './view'
export default Header
