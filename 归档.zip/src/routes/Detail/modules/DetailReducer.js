// action creator

const initState = {
    moduleName: 'detail'
}
export default (state=initState) => {
    return state;
}

