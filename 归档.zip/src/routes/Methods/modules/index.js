const initialState = 'hello world';
export default function reducer (state = initialState, action) {
	return state;
}
